    <script src="<?php echo base_url();?>assets/js/jquery-3.6.0.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

    <script>
        var base_url = "<?php echo base_url();?>";
    </script>
    <script src="<?php echo base_url();?>assets/js/script.js"></script>